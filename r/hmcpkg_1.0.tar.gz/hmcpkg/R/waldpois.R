waldpois <-
function(x,theta0){n=length(x); th = mean(x)
     tst = (sqrt(n/th)*(th-theta0))^2; tst}
